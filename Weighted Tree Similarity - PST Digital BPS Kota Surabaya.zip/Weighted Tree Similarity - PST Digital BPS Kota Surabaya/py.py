from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def main():
    return render_template('c_frame-1.html')

@app.route('/perpus')
def perpus():
    return render_template('katalog.html')

@app.route('/konsul')
def konsul():
    return render_template('c_konsultasi.html')

@app.route('/survey')
def survey():
    return render_template('c_survey-kepuasan.html')


if __name__ == '__main__':
    app.run()