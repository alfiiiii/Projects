-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2024 at 03:11 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `docking`
--

-- --------------------------------------------------------

--
-- Table structure for table `dim_dock`
--

CREATE TABLE `dim_dock` (
  `id_dock` int(11) NOT NULL,
  `nama_dock` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dim_dock`
--

INSERT INTO `dim_dock` (`id_dock`, `nama_dock`) VALUES
(1, 'Irian'),
(2, 'Irian'),
(3, 'Surabaya'),
(4, 'Irian'),
(5, 'Surabaya'),
(6, 'Irian'),
(7, 'Irian'),
(8, 'Irian'),
(9, 'Surabaya'),
(10, 'Irian'),
(11, 'Irian'),
(12, 'Surabaya'),
(13, 'Irian'),
(14, 'Irian'),
(15, 'Irian'),
(16, 'Surabaya'),
(17, 'Surabaya'),
(18, 'Irian'),
(19, 'Irian'),
(20, 'Irian'),
(21, 'Irian'),
(22, 'Irian'),
(23, 'Irian'),
(24, 'Surabaya'),
(25, 'Irian'),
(26, 'Irian'),
(27, 'Surabaya'),
(28, 'Irian'),
(29, 'Irian'),
(30, 'Irian'),
(31, 'Semarang'),
(32, 'Semarang'),
(33, 'Surabaya'),
(34, 'Surabaya'),
(35, 'Irian'),
(36, 'Irian'),
(37, 'Irian'),
(38, 'Semarang'),
(39, 'Irian'),
(40, 'Surabaya'),
(41, 'Irian'),
(42, 'Irian'),
(43, 'Irian'),
(44, 'Surabaya'),
(45, 'Irian'),
(46, 'Irian'),
(47, 'Surabaya'),
(48, 'Irian'),
(49, 'Irian'),
(50, 'Semarang'),
(51, 'Semarang'),
(52, 'Surabaya'),
(53, 'Semarang'),
(54, 'Semarang'),
(55, 'Surabaya'),
(56, 'Semarang'),
(57, 'Semarang'),
(58, 'Irian'),
(59, 'Irian'),
(60, 'Surabaya'),
(61, 'Semarang'),
(62, 'Semarang'),
(63, 'Semarang'),
(64, 'Irian'),
(65, 'Irian'),
(66, 'Surabaya'),
(67, 'Irian'),
(68, 'Semarang'),
(69, 'Surabaya'),
(70, 'Irian'),
(71, 'Surabaya'),
(72, 'Semarang'),
(73, 'Semarang'),
(74, 'Semarang'),
(75, 'Semarang'),
(76, 'Semarang'),
(77, 'Irian'),
(78, 'Semarang'),
(79, 'Irian'),
(80, 'Irian'),
(81, 'Semarang'),
(82, 'Irian'),
(83, 'Irian'),
(84, 'Semarang'),
(85, 'Surabaya'),
(86, 'Irian'),
(87, 'Semarang'),
(88, 'Semarang'),
(89, 'Irian'),
(90, 'Semarang'),
(91, 'Irian'),
(92, 'Irian'),
(93, 'Semarang'),
(94, 'Irian'),
(95, 'Irian'),
(96, 'Semarang'),
(97, 'Surabaya'),
(98, 'Irian'),
(99, 'Semarang'),
(100, 'Semarang'),
(101, 'Semarang'),
(102, 'Semarang'),
(103, 'Surabaya'),
(104, 'Surabaya'),
(105, 'Irian'),
(106, 'Semarang'),
(107, 'Surabaya'),
(108, 'Semarang'),
(109, 'Irian'),
(110, 'Irian'),
(111, 'Irian'),
(112, 'Irian'),
(113, 'Irian'),
(114, 'Irian'),
(115, 'Semarang'),
(116, 'Irian'),
(117, 'Irian'),
(118, 'Surabaya'),
(119, 'Irian'),
(120, 'Semarang'),
(121, 'Semarang'),
(122, 'Surabaya'),
(123, 'Surabaya'),
(124, 'Surabaya'),
(125, 'Surabaya'),
(126, 'Surabaya'),
(127, 'Irian'),
(128, 'Irian'),
(129, 'Irian'),
(130, 'Surabaya'),
(131, 'Semarang'),
(132, 'Semarang'),
(133, 'Surabaya'),
(134, 'Surabaya'),
(135, 'Surabaya'),
(136, 'Irian'),
(137, 'Semarang'),
(138, 'Irian'),
(139, 'Irian'),
(140, 'Semarang'),
(141, 'Surabaya'),
(142, 'Irian'),
(143, 'Irian'),
(144, 'Semarang'),
(145, 'Irian'),
(146, 'Semarang'),
(147, 'Semarang'),
(148, 'Surabaya'),
(149, 'Surabaya'),
(150, 'Surabaya'),
(151, 'Surabaya'),
(152, 'Surabaya'),
(153, 'Irian'),
(154, 'Irian'),
(155, 'Irian'),
(156, 'Surabaya'),
(157, 'Semarang'),
(158, 'Semarang'),
(159, 'Surabaya'),
(160, 'Surabaya'),
(161, 'Surabaya'),
(162, 'Irian'),
(163, 'Semarang'),
(164, 'Irian'),
(165, 'Irian'),
(166, 'Semarang'),
(167, 'Surabaya'),
(168, 'Irian'),
(169, 'Irian'),
(170, 'Semarang'),
(171, 'Surabaya'),
(172, 'Semarang'),
(173, 'Irian'),
(174, 'Irian');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dim_dock`
--
ALTER TABLE `dim_dock`
  ADD PRIMARY KEY (`id_dock`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
