-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2024 at 03:10 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `docking`
--

-- --------------------------------------------------------

--
-- Table structure for table `dim_kapal`
--

CREATE TABLE `dim_kapal` (
  `id_kapal` int(11) NOT NULL,
  `nama_kapal` varchar(255) DEFAULT NULL,
  `no_kontrol` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dim_kapal`
--

INSERT INTO `dim_kapal` (`id_kapal`, `nama_kapal`, `no_kontrol`) VALUES
(1, 'TB Fatimah', 'R21TBFXA'),
(2, 'KM Mutiara Barat', 'R21MTBXA'),
(3, 'AHT Patrona 118', 'R22PTNXA'),
(4, 'KMP Niki Sejahtera', 'R21NSJXA'),
(5, 'KM Tilong Kabila', 'R22TLKXA'),
(6, 'KM Lambelu', 'R22LBUXA'),
(7, 'AHT Patrona 118', 'R22PTNXA'),
(8, 'KMP Niki Sejahtera', 'R21NSJXA'),
(9, 'KM Binaiyah', 'R22BNIXA'),
(10, 'KM Kelimutu', 'R22KMUXA'),
(11, 'KM AWU', 'R22AWUXA'),
(12, 'KM Sarana Lintas Utama', 'R22SLUXA'),
(13, 'KM Sinabung', 'R22SNBXA'),
(14, 'KLM Ayana Lako DI 1', 'R22ALDXA'),
(15, 'KMP Niki Sejahtera (Docking III)', 'R21NSJGA'),
(16, 'AHT Patrona 118 - Docking III', 'R22PTNXA'),
(17, 'KRI Golok', 'R22GLKXA'),
(18, 'KM Mutiara Sentosa III', 'R21MS3XA'),
(19, 'KM Ferindo I', 'R22FR1XA'),
(20, 'KM Baruna Jaya III', 'R22BJ3XA'),
(21, 'SV Etzomer', 'R22EZRXA'),
(22, 'SV Etzomer (Docking II)', 'R22EZRXA'),
(23, 'KM Fatimah IV', 'R22FT4XA'),
(24, 'KM Logistik Nusantara 3', 'R22LN3XA'),
(25, 'KRI Cakra', 'G11ATQY'),
(26, 'BRS', 'T08DFPL'),
(27, 'KM Egon', 'R22EGNXA'),
(28, 'KM Blossom Pescadores', 'R22SBLOXA'),
(29, 'KM Ferindo II', 'R22FR2XA'),
(30, 'km Labobar', 'R22LABXA'),
(31, 'Dharma Ferry V', 'R22DF5XA'),
(32, 'KLM Harmoni', 'R22EPHXA'),
(33, 'KM Logistik Nusantara 2', 'R22LN2XA'),
(34, 'LCM PAL', 'I38ZMND'),
(35, 'KRI Yos Sudarso - 353', 'R22YOSDA'),
(36, 'SV Prospero 9', 'R22PR9XA'),
(37, 'TB Morino 168', 'R22MRNXA'),
(38, 'MT Ratu Ruwaidah', 'R22RRWXA'),
(39, 'KRI Arun - 903', 'R22ARNDA'),
(40, 'KMP Niki Barokah', 'R22NBRXA'),
(41, 'KM Mutiara Timur I', 'R22MT1XA'),
(42, 'KM Lumoso Selamat', 'R22LSMXA'),
(43, 'KT Jaya Negara 401', 'R22JYNXA'),
(44, 'KM Tanto Handal', 'R22THDXA'),
(45, 'KM Mutiara Persada III', 'R22MP3XA'),
(46, 'KMP Niki Sae', 'R22NSEXA'),
(47, 'KM Kirana III', 'R22KR3XA'),
(48, 'KM Dharma Rucitra 8', 'R22DR8XA'),
(49, 'KM Dharma Rucitra 8', 'R22DR8XA'),
(50, 'FC Avant Garde', 'R22AVGXA'),
(51, 'KRI Fatahilah - 361', 'R22FTHXA'),
(52, 'KRI Hasan Basri', 'R23HBSXA'),
(53, 'KRI Dr. Wahidin Sudiro Husodo', 'SATHARMAT KOARMADA II'),
(54, 'KRI Malahayati - 361', 'R22MLHXA'),
(55, 'KMP Prince Soya', 'R23PRSXA'),
(56, 'KM Tilong Kabila', 'R23TLKXA'),
(57, 'SV Geomarini III', 'R23GM3XA'),
(58, 'KRI Bima Suci', 'R23BSCDA'),
(59, 'KM Kirana', 'R23KRNXA'),
(60, 'KRI Teluk Banten - 516', 'R23TBTDA'),
(61, 'KM Lambelu', 'R23LBUXA'),
(62, 'KM Logistik Nusantara 5', 'R23LN5XA'),
(63, 'KM Sinabung', 'R23SNBXA'),
(64, 'KT Jayanegara 402', 'R23JY2XA'),
(65, 'KM Niki Sejahtera', 'R23NSJXA'),
(66, 'KM Leuser', 'R23LSRXA'),
(67, 'KM Bukit Siguntang', 'R23BKSXA'),
(68, 'KM Niki Mila Utama', 'R23NMUXA'),
(69, 'KM Sakira', 'R23SKRXA'),
(70, 'MT Patricia', 'R23PTCXA'),
(71, 'KRI Teluk Ende - 517', 'R23TLEKA'),
(72, 'KM Ratu Ruwaidah', 'R23RRWXA'),
(73, 'MT Salmon Mustafa', 'R23SMFXA'),
(74, 'KM Niki Sejahtera', 'R23NSJXA'),
(75, 'MT Salmon Mustafa', 'R23SMFXA'),
(76, 'MT Salmon Mustafa', 'R23SMFXA'),
(77, 'KM Dharma Kartika 2', 'R22DR8XA'),
(78, 'OFT Apollo', 'R23APLXA'),
(79, 'FC Sovereign 8', 'R22SV8XA'),
(80, 'KM Mutiara Barat', 'R23MTBXA'),
(81, 'FC Straits Ventura II', 'R23SV2XA'),
(82, 'KRI Slamet Riyadi', 'R23SRIDA'),
(83, 'KRI Yos Sudarso', 'R23YOSDA'),
(84, 'MT Patricia', 'R23PTCXA'),
(85, 'KRI Ajak - 653', 'R22FPBXA'),
(86, 'KRI Ahmad Yani', 'R23AMYKA'),
(87, 'KM Logistik Nusantara 6', 'R23LN6XA'),
(88, 'KM Logistik Nusantara 6', 'R23LN6XA'),
(89, 'KM Dharma Kartika 2', 'R22DR8XA'),
(90, 'OFT Apollo', 'R23APLXA'),
(91, 'FC Sovereign 8', 'R22SV8XA'),
(92, 'KM Mutiara Barat', 'R23MTBXA'),
(93, 'FC Straits Ventura II', 'R23SV2XA'),
(94, 'KRI Slamet Riyadi', 'R23SRIDA'),
(95, 'KRI Yos Sudarso', 'R23YOSDA'),
(96, 'MT Patricia', 'R23PTCXA'),
(97, 'KRI Ajak - 653', 'R22FPBXA'),
(98, 'KRI Ahmad Yani', 'R23AMYKA'),
(99, 'KM Logistik Nusantara 6', 'R23LN6XA'),
(100, 'KM Logistik Nusantara 6', 'R23LN6XA'),
(101, 'FC Vanguard', 'R23VGRXA'),
(102, 'KRI Tarakan - 905', 'R23TARDA'),
(103, 'KLM Emperor Harmoni', 'R23EPHXA'),
(104, 'TB Bima', 'R23TBBXA'),
(105, 'KRI Makassar - 590', 'R23MKSDA'),
(106, 'KM Dharma Ferry 5', 'R22DF5XA'),
(107, 'AHTS Kylies', 'R23KYLXA'),
(108, 'KMP Mahkota Nusantara', 'R23MTRXA'),
(109, 'KRI Tarakan - 905', 'R23TARDA'),
(110, 'KRI Diponegoro', 'R23DPNDA'),
(111, 'KRI Surabaya', 'R23SBYDA'),
(112, 'KT Jayanegara 402', 'R23JY2XA'),
(113, 'KRI Diponegoro', 'R23DPNDA'),
(114, 'KRI Surabaya', 'R23SBYDA'),
(115, 'KM Mutiara Ferindo II', 'R23FR2XA'),
(116, 'ASD Tirta Elang', 'R23TEGXA'),
(117, 'KRI Rajiman', 'D72CQYW'),
(118, 'KM Tanto Abadi', 'R23TABXA'),
(119, 'KMP Mahkota Nusantara', 'R23MTRXA'),
(120, 'Kapal M242', 'R2324XA'),
(121, 'Kapal M242', 'R23242XA'),
(122, 'KM Danau Berlian', 'R23DNBXA'),
(123, 'RB Japan', 'J37NIEU'),
(124, 'TB Muria', 'M95UHBK'),
(125, 'RB Japan', 'Y30IITU'),
(126, 'TB Muria', 'O59FEHV'),
(127, 'ASD Tirta Elang', 'R23TEGXA'),
(128, 'KM Dharma Kartika 5', 'R23DT5XA'),
(129, 'KRI REM - 331', 'R23REMCA'),
(130, 'KM Prince Soya', 'R23PRSXB'),
(131, 'ASD Tirta Elang', 'R23TEGXA'),
(132, 'FRD KM Logistik Nusantara I', 'R24LN1XA'),
(133, 'KRI Teluk Weda', 'R24TWDKA'),
(134, 'KM Leuser', 'R24LSRXA'),
(135, 'KRI Teluk Wondama', 'R24TWAXA'),
(136, 'KM Mutiara Persada III', 'R24MP3XA'),
(137, 'KM Sinabung', 'R24SNBXA'),
(138, 'KLM Ayana Lako Dia', 'R24ALDXA'),
(139, 'KMP Mahkota Nusantara', 'R23MTRXA'),
(140, 'KM Dharma Kencana V', 'R24DK5XA'),
(141, 'KM Adventurte', 'R24ADVXA'),
(142, 'RKR Geomarine III', 'R24GMRXA'),
(143, 'KRI Bima Suci', 'R24BSCDA'),
(144, 'KRI Surabaya - 591', 'R24SBYDA'),
(145, 'KMP Mahkota Nusantara', 'R24MTRXA'),
(146, 'Kapal M242', 'R2324XA'),
(147, 'Kapal M242', 'R23242XA'),
(148, 'KM Danau Berlian', 'R23DNBXA'),
(149, 'RB Japan', 'J37NIEU'),
(150, 'TB Muria', 'M95UHBK'),
(151, 'RB Japan', 'Y30IITU'),
(152, 'TB Muria', 'O59FEHV'),
(153, 'ASD Tirta Elang', 'R23TEGXA'),
(154, 'KM Dharma Kartika 5', 'R23DT5XA'),
(155, 'KRI REM - 331', 'R23REMCA'),
(156, 'KM Prince Soya', 'R23PRSXB'),
(157, 'ASD Tirta Elang', 'R23TEGXA'),
(158, 'FRD KM Logistik Nusantara I', 'R24LN1XA'),
(159, 'KRI Teluk Weda', 'R24TWDKA'),
(160, 'KM Leuser', 'R24LSRXA'),
(161, 'KRI Teluk Wondama', 'R24TWAXA'),
(162, 'KM Mutiara Persada III', 'R24MP3XA'),
(163, 'KM Sinabung', 'R24SNBXA'),
(164, 'KLM Ayana Lako Dia', 'R24ALDXA'),
(165, 'KMP Mahkota Nusantara', 'R23MTRXA'),
(166, 'KM Dharma Kencana V', 'R24DK5XA'),
(167, 'KM Adventurte', 'R24ADVXA'),
(168, 'RKR Geomarine III', 'R24GMRXA'),
(169, 'KRI Bima Suci', 'R24BSCDA'),
(170, 'KRI Surabaya - 591', 'R24SBYDA'),
(171, 'KM Leuser', 'R24LSRXA'),
(172, 'KRI Dewaruci', 'R24DRCDA'),
(173, 'KRI OWA - 354', 'R24OWAKA'),
(174, 'SV Indolziz', 'R24IDLDA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dim_kapal`
--
ALTER TABLE `dim_kapal`
  ADD PRIMARY KEY (`id_kapal`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
